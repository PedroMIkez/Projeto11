var sea, seaImage;

var ship, ship_moving;



function preload(){
ship_moving = loadAnimation("ship-4.png", "ship-2.png", "ship-1.png", "ship-3.png");

seaImage = loadImage("sea.png");

}

function setup(){
  createCanvas(600,500);
//criando mar
sea = createSprite(200,190,400,10);
sea.addImage("sea", seaImage);
 //criando barco
 ship = createSprite(50,160,20,50);

 ship.addAnimation("moving", ship_moving);

 ship.scale = 0.1;
ship.x = 100;
ship.y = 200

sea.scale = 0.2
sea.x = 60




}

function draw() {
  background("blue");
    drawSprites();

    sea.velocityX = -4;






    if(sea.x < 0){
      sea.x = sea.width/9;
    }
 
}
